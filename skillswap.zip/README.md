# SkillSwap
A mod that allows you to use the skills of any survivor on any survivor. Can be swapped mid run with Risk of Options.
Skills that break the game on other survivors aren't included.
